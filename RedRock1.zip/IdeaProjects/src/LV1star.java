public class LV1star {
    public static void main(String[] args) {
        for (int i =0;i<6;i++){//第一层
            line.put(i);
            line.star(i);
            System.out.print("*");
            line.star(i);
            line.put(i);
            System.out.println("");
        }
        for (int i=22;i>8;i=i-3){//第二层
            line.put(i);
            line.star(i);
            System.out.print("*");
            line.star(i);
            line.put(i);
            System.out.println("");
        }

        for (int i=15;i>12;i--){//第三层

            line.line((i));
            line.star((24-i));
            line.star(1);
            line.star((24-i));
            line.line(i);
            System.out.println("");
        }
        int m =10;
        for (int i =13;i>=7;i--){//第四层

            line.line(i);
            line.star(m);
            line.line(24-i-m);
            line.line(1);
            line.line(24-i-m);
            line.star(m);
            line.line(i);
            System.out.println("");
            m =m-3;
            if(m ==-2){
                break;
            }
        }
        for (int i =0;i<5;i++){
            line.line(line.LINE);
            System.out.println("");
        }

    }
}

class line{
    public static int LINE = 49;

    public static void put(int x){//输出横线
    if(x>=0){
        for(int j =(LINE-1)/2- x;j>0;j--){
            System.out.print("-");
        }
    }
    }
    public static void star(int y){//输出*
        if(y>=0){
            for (int m =0;m<y;m++){
            System.out.print("*");

            }
        }
    }
    public static void line(int m){
        if(m>0){
        for(int i =0;i<m;i++){
            System.out.print("-");
        }
    }
    }
}
