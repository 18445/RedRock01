import java.util.Scanner;

public class Lv2 {
    public static void main(String[] args) {


    int arr [] =new int[] {55,45,80,105,1024,10,-25,520,1314};
        System.out.println("排序前的结果："+"\n");
    sort.sout(arr);
        System.out.println("");
        System.out.println("冒泡排序后的结果（从大到小）："+"\n");
    sort.bubbleLargeToSmall(arr);
        System.out.println("");
        System.out.println("冒泡排序后的结果（从小到大）："+"\n");
    sort.bubbleSmallToLarge(arr);
        System.out.println("");
        System.out.println("选择排序后的结果（从大到小）："+"\n");
    sort.choiceLargeToSmall(arr);
        System.out.println("");
        System.out.println("选择排序后的结果（从小到大）："+"\n");
    sort.choiceSmallToLarge(arr);
        System.out.println("");
        System.out.println("请输入要插入的数字");
        Scanner in = new Scanner(System.in);
        int number = in.nextInt();
        sort.insert(number,arr);

}
}

class sort{
    public static void insert(int x,int array[]){
//        bubbleWithoutSout(array);
//        int index=array.length;
//        for (int i=0;i< array.length;i++){
//            if(x > array[i]){
//                x=x+array[i];
//                array[i]=x-array[i];
//                x=x-array[i];
//                index = i;
//                break;
//            }
//        }
//        for (int i=0;i< index;i++){
//            System.out.println(array[i]);
//        }
//        System.out.println(x);
//        for (int i=index;i>= index&&i< array.length;i++){
//            System.out.println(array[i]);
//        }
        int array1 [] = new int[array.length+1];
        for (int i =0;i<array.length;i++){
            array1[i] = array[i];
        }
        array1[array1.length-1] = x;
        System.out.println("插入后的顺序：");
        sort.bubbleSmallToLarge(array1);
    }

    public static void sout(int array[]){
        for(int i=0;i< array.length;i++){
            System.out.print(array[i]+"  ");
        }
    }
//    public static void bubbleWithoutSout(int array[]){
//        for(int i=0;i<array.length;i++){
//            for(int j =0;j< array.length-i-1;j++){
//                int temp =0;
//                if(array[j]>array[j+1]){
//                    temp = array[j];
//                    array[j] = array[j+1];
//                    array[j+1] = temp;
//                }
//            }
//        }
//    }
    public static void bubbleSmallToLarge(int array[]){
        for(int i=0;i<array.length;i++){
            for(int j =0;j< array.length-i-1;j++){
                int temp =0;
                if(array[j]>array[j+1]){
                     temp = array[j];
                     array[j] = array[j+1];
                     array[j+1] = temp;
                }
            }
        }
       sout( array );
    }
    public static void bubbleLargeToSmall(int array[]){
        for(int i=0;i<array.length;i++){
            for(int j =0;j< array.length-i-1;j++){
                int temp =0;
                if(array[j]<array[j+1]){
                    temp = array[j];
                    array[j] = array[j+1];
                    array[j+1] = temp;
                }
            }
        }
        sout( array );
    }
    public static void choiceSmallToLarge(int array[]){
        for(int i=0;i< array.length;i++){
            int temp = array[i];
            int x = -1;
                    for(int j=i+1;j< array.length;j++){
                        if(temp>array[j]){
                            temp = array[j];
                            x = j;
                        }
                    }
            if(x!=-1) {
                array[x] = array[i];
                array[i] = temp;
            }
        }
        sout( array );
    }
    public static void choiceLargeToSmall(int array[]){
        for(int i=0;i< array.length;i++){
            int temp = array[i];
            int x = -1;
            for(int j=i+1;j< array.length;j++){
                if(temp<array[j]){
                    temp = array[j];
                    x = j;
                }
            }
            if (x!=-1){
            array[x] = array[i];
            array[i] = temp;
        }
        }
        sout( array );
    }
}


















