import java.util.Scanner;

public class Lv3 {
    public static void main(String [] args){
        System.out.println("输入一个矩阵的行/列：");
        Scanner in =new Scanner(System.in);
        int m = in.nextInt();
        int matrix1[][] = new int[m][m];
        int matrix2[][] = new int[m][m];
        int matrix3[][] = new int[m][m];
        int accumulate1 = 0;
//        int accumulate2 = 0;
        for (int i = 0 ;i<m ;i++){//随机数给矩阵中赋值
            for (int j = 0;j<m ;j++){
                matrix1[i][j]=(int)(1+Math.random()*(99-1+1) );
                matrix2[i][j]=(int)(1+Math.random()*(99-1+1) );
            }
        }
        System.out.println("第一个矩阵：");
        for (int i = 0 ;i<m ;i++){
            for (int j = 0;j<m ;j++){
                System.out.print(matrix1[i][j]+"\t");
            }
            System.out.println("");
        }
        System.out.println("");
        System.out.println("第二个矩阵：");
        for (int i = 0 ;i<m ;i++){
            for (int j = 0;j<m ;j++){
                System.out.print(matrix2[i][j]+"\t");
            }
            System.out.println("");
        }
        for (int i =0;i<m ;i++){                             //行
            for (int j =0;j<m ;j++){                         //列
                 for (int k = 0; k < m; k++){                //一行*一列
                matrix3[i][j] +=( matrix1[i][k] * matrix2[k][j]);
            }
            }
        }
        System.out.println("相乘后的矩阵：");
        for (int i = 0 ;i<m ;i++){
            for (int j = 0;j<m ;j++){
                System.out.print(matrix3[i][j]+"\t");
            }
            System.out.println("");
        }
        for (int i =0;i<m ;i++){

                    accumulate1 += matrix3[m-i-1][i];
//                    accumulate2 += matrix3[i][m-i-1];

        }
//        System.out.println("对角线的和分别为："+accumulate1 +"和" + accumulate2);
//        两个对角线的和居然是一样的，(orz
        System.out.println("对角线的和为："+accumulate1 );

    }
}
