/*
知识点：
类的设计（需要一个菜品类和一个餐厅类）
菜品类的属性包括（1.菜名2.价格3.菜单号）
餐厅类的属性包括（餐厅的名字）方法包括（1.支付的方法2.欢迎功能）
对象的创建
对象数据和数组的遍历
 */


public class Lv4 {
    static boolean  eat = true;
    public static void main(String[] args) {
        Order order[] = new Order[5];
        order[0] = new Order("辣子鸡丁",38,1);
        order[1] = new Order("水煮肉片",22,2);
        order[2] = new Order("糖醋里脊",18,3);
        order[3] = new Order("干锅牛肉",38,4);
        order[4] = new Order("干锅排骨",29,5);


            restaurant.getInstance().welcome();
            restaurant.getInstance().choice(order);
            Order.food(order);
            while(eat) {
                restaurant.getInstance().welcome();
//                if (restaurant.choice == 1){
//                    Order.listPrice(order);
//                }else{
//                    Order.listName(order);
//                }
                restaurant.getInstance().choice(order);
                if (Order.INDEX<5&&eat == true) {
                    Order.food(order);
                }else if(eat == true){
                    System.out.println("您的菜数量过多，请稍后再点");
                    break;
                }
            }
            restaurant.getInstance().pay();
    }
}
