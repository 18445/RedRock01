import java.util.Scanner;

public class Lv5 {
    public static void main(String[] args){
        Scanner in = new Scanner(System.in);
        System.out.println("请选择数组长度：");
        int size = in.nextInt();
        MutableArrayList list = new MutableArrayList(size);
        while(true){
        System.out.println("请选择你要选择的功能");
        System.out.println("1：增加元素");
        System.out.println("2：索引查找");
        System.out.println("3：索引删除");
        System.out.println("4：索引添加");
        System.out.println("5：内容删除");
        System.out.println("6：遍历元素");
        System.out.println("0：退出选择");
        int choice = in.nextInt();
        switch(choice){
            case 1:
                System.out.println("输入想要添加的内容：");
                String null1 = in.nextLine();
                String content = in.nextLine();
                list.add(content);
                break;
            case 2:
                System.out.println("输入想要查找的位置：");
                int index1 = in.nextInt();
                list.get(index1);
                break;
            case 3:
                System.out.println("输入想要删除的位置：");
                int index2 = in.nextInt();
                list.remove(index2);
                break;
            case 4:
                System.out.println("输入想要添加的内容及位置：");
                int index3 =in.nextInt();
                String null2 = in.nextLine();
                String content1 = in.nextLine();
                list.add(index3,content1);
                break;
            case 5:
                System.out.println("输入想要删除的内容");
                String null3 = in.nextLine();
                String content2 = in.nextLine();
                list.remove(content2);
                break;
            case 6:
                list.sout();
                break;
            case 0:
                System.exit(0);
            default:
                System.out.println("输入有误，请重新输入。");

        }
    }
    }
}
