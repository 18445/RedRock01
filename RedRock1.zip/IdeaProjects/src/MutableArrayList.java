public class MutableArrayList {
    private Object[] elementDate;
    private static int SIZE;


    public MutableArrayList(int SIZE){
        this.SIZE = SIZE;

        elementDate = new Object[SIZE];
    }
    public void add(Object obj){
        for(int i = 0;i<elementDate.length;i++){//遍历数组
            if (elementDate[i] == null) {//判断是否有为空的位置
                elementDate[i] = obj;
                return;
            }
        }
        Object[] newElementDate = new Object[++SIZE];
        for(int i = 0;i< newElementDate.length -1 ;i++){//新建数组
            newElementDate[i] = elementDate[i];
        }
        newElementDate[SIZE-1] = obj;
        //新数组赋予给原来的数组
//         elementDate = new Object[SIZE-1];
//        for(int i = 0;i< newElementDate.length  ;i++){
//            elementDate [i] = newElementDate[i];
//        }
        elementDate = newElementDate;



    }
    public void get (int index){
        System.out.println("元素长度为: "+elementDate.length);
        judge(index);
        System.out.println(elementDate[index-1]);
    }
    public void remove(Object obj){
        for (int i = 0;i< elementDate.length;i++){
            if (elementDate[i].equals(obj)){
                Object []newElementdate = new Object[elementDate.length - 1];
                for(int j = i;j<elementDate.length-1;j++){
                newElementdate [j] =elementDate [j+1];
                }
                elementDate = newElementdate;
                --SIZE;
                return;
            }
        }
        System.out.println("输入内容查找无效");
    }
    public void remove(int index){
        judge(index);
        Object []newElementdate = new Object[elementDate.length - 1];
        for(int j = index;j<elementDate.length;j++){//覆盖指定元素
            newElementdate [j] =elementDate [j+1];
        }
        elementDate = newElementdate;
        --SIZE;
        return;

    }
    public void add(int index,Object obj){
        judge(index);
        for(int i =0;i<elementDate.length;i++){
            if(index -1 == i){
                Object newElementdate[] = new Object[elementDate.length + 1];
                for(int j = 0 ;j<i;j++){
                    newElementdate[j] =elementDate[j];
                }

                for(int j = i + 1;j<newElementdate.length;j++){
                    newElementdate[j] = elementDate [j-1];
                }
                newElementdate[i] = obj;
                elementDate = newElementdate;
                return;
            }
        }
    }

    public void judge(int index){
        if(index > elementDate.length){
            System.out.println("输入编号过大。");
            return;
        }else if (index <= 0){
            System.out.println("输入编号过小。");
            return;
        }
    }

    public void sout(){
        System.out.println("里面的内容有如下：");
        for (int i =0;i<elementDate.length;i++){
            if(elementDate[i]!=null){
            System.out.print(elementDate[i]+"  ");
        }
        }
        System.out.println("");
    }


}
