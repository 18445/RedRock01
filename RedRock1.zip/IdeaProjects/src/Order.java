import java.sql.SQLOutput;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class Order {
    private String name;
    private int price;
    private int num;
    public Order(){

    }

    public Order(String name,int price,int num){
        this.name = name;
        this.price = price;
        this.num = num;
    }

    public static void listPrice(Order order[]){
        for(int i=0;i<order.length;i++){
            for(int j =0;j< order.length-i-1;j++){
                Order temp1 = new Order();
                if(order[j].price>order[j+1].price){
                    temp1 = order[j];
                    order[j] = order[j+1];
                    order[j+1] = temp1;
                }
            }
        }
        for(int i=0;i<order.length;i++){
            System.out.println((i+1)+"."+order[i].name+" "+order[i].price+"元");
        }
    }
    public static void listName(Order order[]){
        for(int i=0;i<order.length;i++){
            for(int j =0;j< order.length-i-1;j++){
                Order temp1 = new Order();
                if(order[j].num>order[j+1].num){
                    temp1 = order[j];
                    order[j] = order[j+1];
                    order[j+1] = temp1;
                }
            }
        }
        for (int i = 0; i < 5; i++) {
            System.out.println(order[i].num+"."+order[i].name+" "+order[i].price+"元");
        }
    }
        static int sum[] = new int[100];
        static int cost = 0;
        static int INDEX = 0;
    public static void food(Order order[]){
        System.out.println("请输入您想要点的菜：");
        Scanner in = new Scanner(System.in);
        int num = in.nextInt();

        sum[INDEX] = num;
        System.out.println("你一共选择了："+(INDEX+1) + "道菜");
        INDEX++;
//        if(INDEX<5)
//        {INDEX++;}
        int x = 0;
        for (int i = 0;i<order.length;i++){
            if(order[i].num ==num){
                x = i;
                sum[INDEX] = x;
            }
        }
        cost+=order[num-1].price;
        for(int y =0;y<INDEX;y++){
            System.out.println((order[sum[y]-1].name)+" "+order[sum[y]-1].price+"元");

        }

        System.out.println("一共花费了"+cost+"元");

    }

}
