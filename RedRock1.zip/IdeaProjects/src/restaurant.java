import java.util.Scanner;

public class restaurant {
    static int choice = 0;
    private static restaurant restaurant = new restaurant();
    private static String name ;
    public static restaurant getInstance(){
        return restaurant;
    }
    static{
        name = "国民饭店";
    }
    public void welcome(){
        System.out.println("欢迎来到"+restaurant.name+"，这是今天的菜单：");
    }

    public void choice(Order order[]){


        System.out.println("1：按菜单名");
        System.out.println("2:按价格");
        System.out.println("0:退出");
        Scanner in =new Scanner(System.in);
        choice = in.nextInt();
        switch(choice){
            case 1:
                Order.listName(order);
                break;
            case 2:
                Order.listPrice(order);
                break;
            case 0:
                Lv4.eat = false;
                break;
            default:
                System.out.println("输入有误");


        }

    }

    public void pay() {
        System.out.println("请选择支付方式");
        System.out.println("1:支付宝");
        System.out.println("2：微信");
        System.out.println("3:人脸识别");
        Scanner in = new Scanner(System.in);
        choice = in.nextInt();
        switch (choice) {
            case 1:
                System.out.println("请出示付款码");
                System.out.println("........");
                System.exit(0);
            case 2:
                System.out.println("请出示付款码");
                System.out.println("........");
                System.exit(0);
            case 3:
                System.out.println("请对准相机");
                System.out.println("........");
                System.exit(0);
            default:
                System.out.println("输入有误");
        }
    }

}
